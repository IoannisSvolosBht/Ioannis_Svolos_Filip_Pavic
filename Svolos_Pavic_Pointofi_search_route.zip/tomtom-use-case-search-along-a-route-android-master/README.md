Search along a route
============
Sample application created as a result of the tutorial: [Search along a route](https://developer.tomtom.com/search-along-route).
